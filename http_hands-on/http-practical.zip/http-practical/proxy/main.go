﻿package main

import (
"log"
"net/http"
"net/http/httputil"
"net/url"
"os"
"strings"

"github.com/golang-jwt/jwt/v5"
)

func main() {
secret := os.Getenv("JWT_SECRET")
upstream := os.Getenv("UPSTREAM_URL")

if secret == "" || upstream == "" {
log.Fatal("JWT_SECRET and UPSTREAM_URL are required")
}

target, err := url.Parse(upstream)
if err != nil {
log.Fatal(err)
}

reverseProxy := httputil.NewSingleHostReverseProxy(target)

http.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
auth := r.Header.Get("Authorization")

if !strings.HasPrefix(auth, "Bearer ") {
http.Error(w, "Unauthorized", http.StatusUnauthorized)
return
}

tokenString := strings.TrimPrefix(auth, "Bearer ")

token, err := jwt.Parse(
tokenString,
func(token *jwt.Token) (interface{}, error) {
if token.Method != jwt.SigningMethodHS256 {
return nil, jwt.ErrSignatureInvalid
}
return []byte(secret), nil
},
jwt.WithValidMethods([]string{"HS256"}),
jwt.WithExpirationRequired(),
)

if err != nil || !token.Valid {
http.Error(w, "Invalid or expired token", http.StatusUnauthorized)
return
}

reverseProxy.ServeHTTP(w, r)
})

log.Println("JWT Proxy listening on port 8081")
log.Fatal(http.ListenAndServe(":8081", nil))
}
